# 🤖 PROMPT VOOR CLAUDE CODE

**Kopieer onderstaande prompt en plak in Claude Code:**

---

## 📋 START PROMPT (kopieer alles hieronder):

```
Hoi Claude. Ik wil dat je een complete Progressive Web App bouwt: een familie-arcade gokkast in stijl van de klassieke Bellfruit Club 2000 (1989) / Stakelogic Club 2000 Deluxe (online versie). 

Project: FAMILIE CLUB 2000

In deze directory vind je een blueprint met alle instructies:
- README.md = overzicht
- CLAUDE.md = bouw fases (lees DIT eerst en volg het stap voor stap)
- SPEC.md = exacte gameplay regels (echt Club 2000 mechanics)
- ASSETS.md = familieleden + tier configuratie
- HOSTING.md = GitHub Pages deploy stappen

In `assets/familie/` staan 23 PNG's van familieleden (Moek, Kawita, Shreya, Geetha, Sindy, Roy, Richella, Bella, Naleya, Devan, Jennifer, loek, Amaya, Anisa, Armando, Berry, Chella, Chloé, Daan, Ervina, Gaby, Shira, Stich).

In `assets/icons/` staan al gegenereerde PWA icons.

In `src/` staan starter files (data, state, audio synth) waar je op kan voortbouwen.

WAT IK WIL:
- Vanilla JS PWA, geen build step, geen externe libs (alleen Google Fonts)
- 3 rollen onderpaneel + bovenpaneel met Club Meter cirkel + 9 LED dots
- Moek = JACKPOT symbool (3x op winlijn = +200 + speciale animatie)
- Mystery prijzen voor 2x of 3x Moek kris-kras (random 4-100)
- Kop/Munt gamble met flitsende LED cursor (~120ms swap), HEADS/TAILS knoppen om te stoppen
- Hold knoppen onder rollen
- Background music (Web Audio synth, mute toggle)
- Sound effects voor alles (reels, wins, gamble, jackpot)
- Popups voor wins, jackpot, mystery, out-of-credits, help, settings
- LocalStorage stats (jackpots, gambles, etc.)
- Service worker voor offline werking
- Mobile-first responsive (360-480px breed primair)
- Installable als PWA op iOS + Android

GEEN:
- Geen echt geld
- Geen frameworks (React, Vue, etc.)
- Geen bundlers (Webpack, Vite, etc.)
- Geen externe APIs

WERKWIJZE:
1. Lees CLAUDE.md helemaal door
2. Lees SPEC.md voor de exacte mechanics
3. Lees ASSETS.md voor de symbool tier configuratie
4. Bouw in de 11 fases zoals beschreven in CLAUDE.md
5. Test elke fase voor je verder gaat
6. Geef me na elke 3 fases een korte status update
7. Aan het eind: zorg dat het via `npx serve .` werkt en alle Definition of Done checks groen zijn

LET OP:
- Win evaluatie: zie SPEC.md sectie 4 voor het exacte algoritme (winlijn + kris-kras voor 9 zichtbare posities)
- Kop/Munt: cursor MOET echt flitsen tussen KOP/MUNT met LED dots ertussen (zoals echte gokkast). Speler drukt HEADS knop = cursor stopt op KOP.
- Moek jackpot: cabinet shake + goud confetti + Moek's foto vergroot + speciale jingle
- Mystery: spinnende Moek + cijfers flitsen voor random reveal

START MET FASE 1. Maak alle bestanden zoals in CLAUDE.md beschreven, bouw daadwerkelijke werkende code (geen placeholders). Geef me na fase 1 een korte status en wacht op mijn "ga door" voor fase 2, anders ga je gewoon door tot fase 11.

Vragen voor je begint?
```

---

## 🎯 Korte versie (als je geen lange prompt wil)

Als de bovenstaande te lang is, gebruik deze kortere:

```
Lees CLAUDE.md, SPEC.md en ASSETS.md in deze folder. 

Bouw daarna een complete Progressive Web App: Familie Club 2000 — een familie gokkast in stijl van de klassieke Bellfruit/Stakelogic Club 2000, met 23 familieleden als symbolen en Moek als jackpot. 

Volg de 11 fases in CLAUDE.md exact. Vanilla JS, geen frameworks. Mobile-first PWA. Inclusief background music, popups, animaties, kop/munt gamble met flitsende cursor, en deploy-ready voor GitHub Pages.

Begin bij fase 1 en werk door tot het werkt. Test op `npx serve .` als je klaar bent.
```

---

## 🔧 Tips voor het werken met Claude Code

### Voor je begint
```bash
cd familie-club2000
git init
git add .
git commit -m "Initial blueprint"
```

### Tijdens het bouwen
- Laat Claude Code **fase per fase** werken, niet alles in 1 keer
- Test na elke fase in de browser
- Geef Claude feedback: "fase 4 reels draaien te snel, maak slower"

### Als iets niet werkt
- Open browser DevTools (F12) → Console
- Plak errors terug naar Claude Code: "ik krijg deze error: [paste]"

### Versie controle
Na elke werkende fase:
```bash
git add .
git commit -m "Fase 4: reels werken"
```

Zo kan je terug als iets fout gaat.

### Live testen op telefoon (lokaal)
```bash
# Find je lokale IP
ipconfig getifaddr en0   # macOS
ip a | grep inet         # Linux

# Start server op alle interfaces
npx serve . -l 0.0.0.0:3000

# Op je telefoon: http://JOUW-IP:3000
```

---

## 🚀 Deployen naar GitHub Pages

```bash
# Maak GitHub repo aan op github.com (familie-club2000)

git remote add origin git@github.com:moekclaw72/familie-club2000.git
git push -u origin main

# Op GitHub: Settings → Pages → Source: main, root folder
# Wacht 1-2 min, check: https://moekclaw72.github.io/familie-club2000/
```

---

## ✅ Final checklist voor lancering

- [ ] App werkt op iPhone Safari (test fysiek)
- [ ] App werkt op Android Chrome (test fysiek)
- [ ] Installable als PWA (Add to Home Screen werkt)
- [ ] Offline werkt (DevTools → Network → Offline → refresh)
- [ ] Geluid werkt (mute toggle, music volume)
- [ ] Moek jackpot voelt speciaal
- [ ] Kop/Munt cursor flitst echt
- [ ] Stats worden bewaard (localStorage)
- [ ] Lighthouse PWA score ≥ 90
- [ ] Geen console errors
- [ ] Gedeeld in familie WhatsApp groep 🎉

---

## 💡 Verdienmodel hooks (post-launch)

Als de app draait en de familie het leuk vindt:

1. **Familie versie** voor anderen — €9 eenmalig voor eigen versie met hun foto's
2. **Horeca versie** — €99 setup + €19/maand voor cafés/eetcafés
3. **Bedrijfsfeestjes** — €149 voor team gokkast op personeelsfeest
4. **Adverteren in huis-aan-huis bladen** in Nederlandse regio's
5. **TikTok showcase** — laat zien hoe makkelijk eigen versie te maken is

Eerste klant: **De Rotterdammer eetcafé** — vervang familie door menu items, gokkast voor in het café.
